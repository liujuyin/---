import os
import numpy as np
from sanic import Sanic, response
import asyncio
from shapely.geometry import shape, box

app = Sanic("PopulationQueryService")

# 数据路径和配置
GRID_DATA_DIR = r"//Users//liujuyin//Documents//vis-pythonproject//processed_data"
INDEX_FILE_PATH = os.path.join(GRID_DATA_DIR, "population_index.npy")
CELL_SIZE = 1 / 120  # 每个栅格单元的大小，单位：度（30秒 = 1/120度）

# 加载索引文件
INDEX_DATA = np.load(INDEX_FILE_PATH, allow_pickle=True).tolist()

# 设置请求和响应超时
app.config.REQUEST_TIMEOUT = 300
app.config.RESPONSE_TIMEOUT = 300

@app.post("/query_population")
async def query_population(request):
    """
    查询多边形人口总数
    """
    try:
        # 从请求中解析GeoJSON
        geojson = request.json
        polygon = shape(geojson["geometry"])  # 转换为Shapely Polygon

        # 获取多边形边界
        bounds = polygon.bounds  # (min_lon, min_lat, max_lon, max_lat)
        min_lon, min_lat, max_lon, max_lat = bounds

        # 筛选出相关的二进制文件
        relevant_files = filter_files_by_bounds(min_lon, max_lon, min_lat, max_lat)

        # 计算总人口数
        total_population = 0
        details = []
        tasks = []
        for file_info in relevant_files:
            tasks.append(calculate_population_for_grid(file_info, polygon))
        
        results = await asyncio.gather(*tasks)
        total_population = sum(result[0] for result in results)
        details = [detail for result in results for detail in result[1]]
        

        return response.json({
            "total_population": total_population,
            "details": details
        })

    except Exception as e:
        return response.json({"error": str(e)}, status=500)


def filter_files_by_bounds(min_lon, max_lon, min_lat, max_lat):
    """
    根据查询边界筛选相关的二进制文件
    """
    relevant_files = []
    for file_info in INDEX_DATA:
        if (
            file_info["lon_max"] < min_lon or file_info["lon_min"] > max_lon or
            file_info["lat_max"] < min_lat or file_info["lat_min"] > max_lat
        ):
            continue
        relevant_files.append(file_info)
    return relevant_files


async def calculate_population_for_grid(file_info, polygon):
    """
    计算多边形与某个grid文件相交部分的人口
    """
    try:
        grid_path = os.path.join(GRID_DATA_DIR, file_info["filename"])
        grid_data = np.load(grid_path)
        print(grid_path)
        lon_min = file_info["lon_min"]
        lat_max = file_info["lat_max"]
        print(file_info["lon_min"], file_info["lon_max"], file_info["lat_min"], file_info["lat_max"])


        # 获取查询多边形的边界范围（仅考虑与当前文件范围重叠部分）
        query_lon_min, query_lat_min, query_lon_max, query_lat_max = polygon.bounds
        print(query_lon_min, query_lat_min, query_lon_max, query_lat_max)
        
        # 限制遍历范围：通过比较矩形和文件的边界，找到重合部分
        col_start = max(0, int((query_lon_min - lon_min) / CELL_SIZE))
        col_end = min(grid_data.shape[1], int((query_lon_max - lon_min) / CELL_SIZE) + 1)
        row_start = max(0, int((lat_max - query_lat_max) / CELL_SIZE))
        row_end = min(grid_data.shape[0], int((lat_max - query_lat_min) / CELL_SIZE) + 1)
        print(row_start, row_end, col_start, col_end)
        
        # 构建裁剪范围
        cell_population = 0
        cell_details = []
        for i in range(row_start, row_end):
            for j in range(col_start, col_end):
                if np.isnan(grid_data[i, j]):
                    continue

                # 单元格的四个角点经纬度
                cell_polygon = box(
                    lon_min + j * CELL_SIZE, lat_max - (i + 1) * CELL_SIZE,  # 左下角
                    lon_min + (j + 1) * CELL_SIZE, lat_max - i * CELL_SIZE  # 右上角
                )

                # 检查单元格是否与查询多边形相交
                if cell_polygon.intersects(polygon):
                    # 计算相交部分的面积
                    intersection = cell_polygon.intersection(polygon)
                    cell_area = intersection.area
                    population = grid_data[i, j] * (cell_area / cell_polygon.area)
                    cell_population += population
                    cell_details.append({
                        "lon_min": lon_min + j * CELL_SIZE,
                        "lat_max": lat_max - i * CELL_SIZE,
                        "population": population
                    })
                    
        return cell_population, cell_details  
    except Exception as e:
        print(f"处理文件时出错: {e}")
        return 0, []
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, access_log=True)