import numpy as np
import os

# 输入和输出目录
input_dir = r"//Users//liujuyin//Documents//vis-pythonproject//data"
output_dir = r"//Users//liujuyin//Documents//vis-pythonproject//processed_data"

os.makedirs(output_dir, exist_ok=True)

# 每度的格网数量
factor = 120

def process_asc_file(file_path):
    """处理单个ASC文件，返回数据及经纬度范围"""
    with open(file_path) as f:
        # 读取头信息
        ncols = int(f.readline().split()[1])
        nrows = int(f.readline().split()[1])
        xllcorner = float(f.readline().split()[1])
        yllcorner = float(f.readline().split()[1])
        cellsize = float(f.readline().split()[1])
        nodata_value = float(f.readline().split()[1])

    # 加载数据并处理无效值
    data = np.genfromtxt(file_path, skip_header=6)
    data[data == nodata_value] = np.nan

    # 计算经纬度范围
    lon_min = xllcorner
    lon_max = xllcorner + ncols * cellsize
    lat_min = yllcorner
    lat_max = yllcorner + nrows * cellsize

    return data, (lon_min, lon_max, lat_min, lat_max)

# 初始化索引列表
index = []

# 遍历目录下的所有ASC文件
for filename in sorted(os.listdir(input_dir)):
    if filename.endswith('.asc'):
        file_path = os.path.join(input_dir, filename)
        print(f"Processing {filename}...")

        data, (lon_min, lon_max, lat_min, lat_max) = process_asc_file(file_path)

        # 将数据保存为独立的 NPY 文件
        npy_path = os.path.join(output_dir, f"{os.path.splitext(filename)[0]}.npy")
        npy_filename = f"{os.path.splitext(filename)[0]}.npy"
        np.save(npy_path, data)
        print(f"Saved to {npy_path}")
        ¥
        # 记录当前文件的索引信息
        index.append({
            'filename': npy_filename,
            'lon_min': lon_min,
            'lon_max': lon_max,
            'lat_min': lat_min,
            'lat_max': lat_max,
            'shape': data.shape
        })
# 保存索引文件
index_file = os.path.join(output_dir, 'population_index.npy')
np.save(index_file, index)
print(f"All ASC files have been processed and saved as individual NPY files. Index file saved to {index_file}.")
