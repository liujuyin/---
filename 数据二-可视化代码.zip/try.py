import sys
import requests
import json
import numpy as np  # 新增：用于数值处理
from sklearn.preprocessing import MinMaxScaler  # 新增：用于数据归一化
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QPushButton, QLabel,
    QDialog, QLineEdit, QHBoxLayout, QMessageBox, QListWidget
)
from PyQt5.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
from shapely.geometry import Polygon
from shapely.geometry.polygon import orient
from matplotlib.colors import LinearSegmentedColormap
from mpl_toolkits.basemap import Basemap

SERVER_URL = "http://127.0.0.1:8000/query_population"

class CoordinateInputDialog(QDialog):
    """
    弹出窗口：用于输入坐标点
    """
    def __init__(self):
        super().__init__()
        self.setWindowTitle("新增坐标点")
        self.setFixedSize(300, 100)
        layout = QVBoxLayout()

        self.coord_input = QLineEdit()
        self.coord_input.setPlaceholderText("请输入经纬度 (例如: -20, 70)")
        layout.addWidget(self.coord_input)

        button_layout = QHBoxLayout()
        self.ok_button = QPushButton("OK")
        self.cancel_button = QPushButton("Cancel")
        button_layout.addWidget(self.ok_button)
        button_layout.addWidget(self.cancel_button)

        layout.addLayout(button_layout)
        self.setLayout(layout)

        self.ok_button.clicked.connect(self.accept)
        self.cancel_button.clicked.connect(self.reject)

    def get_coordinates(self):
        """
        返回用户输入的经纬度
        """
        return self.coord_input.text()

class PopulationQueryApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("全球人口分布查询系统")
        self.resize(800, 600)

        # 初始化组件
        self.coord_list = []  # 存储坐标列表
        self.coordinate_display = QListWidget()

        self.new_button = QPushButton("新增坐标点")
        self.delete_button = QPushButton("删除选中点")
        self.query_button = QPushButton("查询")
        self.plot_canvas = FigureCanvas(plt.figure())

        # 布局
        layout = QVBoxLayout()
        layout.addWidget(QLabel("当前坐标列表:"))
        layout.addWidget(self.coordinate_display)
        button_layout = QHBoxLayout()
        button_layout.addWidget(self.new_button)
        button_layout.addWidget(self.delete_button)
        button_layout.addWidget(self.query_button)
        layout.addLayout(button_layout)
        layout.addWidget(self.plot_canvas)

        self.setLayout(layout)

        # 绑定事件
        self.new_button.clicked.connect(self.add_new_coordinate)
        self.delete_button.clicked.connect(self.delete_selected_coordinate)
        self.query_button.clicked.connect(self.perform_query)

        # 绘制初始世界地图
        self.draw_world_map()

    def draw_world_map(self):
        """
        绘制全局世界地图，标注经纬度坐标。
        """
        self.plot_canvas.figure.clear()
        ax = self.plot_canvas.figure.add_subplot(111)

        m = Basemap(projection='mill',
                    llcrnrlon=-180, llcrnrlat=-90,
                    urcrnrlon=180, urcrnrlat=90,
                    resolution='c', ax=ax)

        m.drawcoastlines()
        m.drawcountries()
        m.drawparallels(range(-90, 91, 30), labels=[1, 0, 0, 0])
        m.drawmeridians(range(-180, 181, 60), labels=[0, 0, 0, 1])

        ax.set_title("World Map")
        self.plot_canvas.draw()

    def add_new_coordinate(self):
        """
        新增坐标点
        """
        dialog = CoordinateInputDialog()
        if dialog.exec_() == QDialog.Accepted:
            coord_text = dialog.get_coordinates()
            try:
                lon, lat = map(float, coord_text.split(","))
                self.coord_list.append((lon, lat))
                self.coordinate_display.addItem(f"经度: {lon}, 纬度: {lat}")
            except ValueError:
                QMessageBox.warning(self, "输入错误", "请输入正确的经纬度格式 (例如: -20, 70)")

    def delete_selected_coordinate(self):
        """
        删除选中的坐标点
        """
        selected_items = self.coordinate_display.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "删除错误", "请先选择一个点进行删除！")
            return

        for item in selected_items:
            index = self.coordinate_display.row(item)
            self.coord_list.pop(index)
            self.coordinate_display.takeItem(index)

    def perform_query(self):
        """
        执行查询：检查坐标是否构成多边形，并查询人口数据
        """
        if len(self.coord_list) < 3:
            QMessageBox.warning(self, "错误", "坐标点不足，无法构成多边形！")
            return

        try:
            polygon = Polygon(self.coord_list)
            if not polygon.is_valid or not polygon.is_simple:
                raise ValueError("多边形无效或自相交！")

            # 确保多边形闭合
            if list(polygon.exterior.coords)[-1] != list(polygon.exterior.coords)[0]:
                coords = list(polygon.exterior.coords)[:-1]
            else:
                coords = list(polygon.exterior.coords)

            # 转换为GeoJSON格式
            geojson = {
                "type": "Feature",
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [coords],
                },
                "properties": {}
            }

            # 发送查询请求
            response = requests.post(SERVER_URL, json=geojson)
            if response.status_code != 200:
                print(f"响应内容: {response.text}")
                raise Exception("查询失败，服务器错误！")
            result = response.json()
            self.display_results(result)
        except Exception as e:
            QMessageBox.critical(self, "查询错误", str(e))

    def display_results(self, data):
        """
        显示查询结果，并绘制热力图（优化颜色分布和密度）
        """
        total_population = data.get("total_population", 0)
        details = data.get("details", [])

        QMessageBox.information(self, "查询成功", f"总人口: {total_population}")

        # 1. 优化颜色梯度：调整颜色节点，让红色更早出现
        colors = [(1, 1, 1), (1, 1, 0), (1, 0.5, 0), (1, 0, 0), (0, 0, 0)]  # 新增橙色过渡，红色提前
        n_bins = 200  # 增加梯度分隔数量（原100），让颜色更细腻
        cmap_name = "custom_colormap"
        custom_cmap = LinearSegmentedColormap.from_list(cmap_name, colors, N=n_bins)

        # 绘制地图和热力图
        self.plot_canvas.figure.clear()
        ax = self.plot_canvas.figure.add_subplot(111)

        # 设置 Basemap
        m = Basemap(projection='merc',
                    llcrnrlon=min(lon for lon, lat in self.coord_list) - 1,
                    llcrnrlat=min(lat for lon, lat in self.coord_list) - 1,
                    urcrnrlon=max(lon for lon, lat in self.coord_list) + 1,
                    urcrnrlat=max(lat for lon, lat in self.coord_list) + 1,
                    resolution='i', ax=ax)

        m.drawcoastlines()
        m.drawcountries()
        m.drawparallels(range(-90, 91, 10), labels=[1, 0, 0, 0])
        m.drawmeridians(range(-180, 181, 10), labels=[0, 0, 0, 1])

        # 绘制蓝色框框表示查询范围
        lons, lats = zip(*self.coord_list)
        lons = list(lons) + [lons[0]]
        lats = list(lats) + [lats[0]]
        x, y = m(lons, lats)
        m.plot(x, y, marker=None, color='blue', linewidth=2, label="查询范围")

        if details:
            scatter_lons = [item["lon_min"] for item in details]
            scatter_lats = [item["lat_max"] for item in details]
            populations = [item["population"] for item in details]

            # 2. 优化数值归一化：降低红色阈值，让颜色分布更密集
            # 步骤1：平方根拉伸（保留原有逻辑）
            sqrt_pop = np.array([p ** 0.5 for p in populations])
            # 步骤2：归一化到0-1范围
            scaler = MinMaxScaler(feature_range=(0, 1))
            norm_pop = scaler.fit_transform(sqrt_pop.reshape(-1, 1)).flatten()
            # 步骤3：强制降低红色阈值（比如让0.7以上就到红色区间）
            norm_pop = np.clip(norm_pop * 1.4, 0, 1)  # 数值放大1.4倍，超过1的截断为1

            scatter_x, scatter_y = m(scatter_lons, scatter_lats)

            # 3. 优化散点密度：增大点的大小（s从50→80），减小边缘空白
            scatter = ax.scatter(
                scatter_x, scatter_y,
                c=norm_pop,          # 归一化后的人口值
                cmap=custom_cmap,    # 优化后的颜色梯度
                s=80,                # 增大点的尺寸，更密集
                edgecolor='none',
                alpha=0.8            # 增加透明度，重叠点更清晰
            )
            plt.colorbar(scatter, ax=ax, label='Population (scaled)')

        ax.set_title(f"Total population: {total_population}")
        self.plot_canvas.draw()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_window = PopulationQueryApp()
    main_window.show()
    sys.exit(app.exec_())